import sys
import torch
import numpy as np
import pyqtgraph as pg
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTimer
import logging
from mindrove.board_shim import BoardShim, MindRoveInputParams, BoardIds
from mindrove.data_filter import DataFilter, FilterTypes, DetrendOperations
import pandas as pd
from scipy.signal import butter, filtfilt
from scipy.ndimage import gaussian_filter
import time

def butter_bandpass_filter(data, lowcut, highcut, fs, order=4):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    y = filtfilt(b, a, data)
    return y

def butter_lowpass_filter(data, cutoff, fs, order=4):
    nyquist = 0.5 * fs
    normal_cutoff = cutoff / nyquist
    b, a = butter(order, normal_cutoff, btype='low')
    y = filtfilt(b, a, data)
    return y

def process_emg_channel(emg_data, fs=500):
    # Convert to mV
    emg_data = emg_data * 0.045
    
    # Bandpass filter
    bandpassed = butter_bandpass_filter(emg_data, 20, 249, fs)
    
    # Rectification
    rectified = np.abs(bandpassed)
    
    # Envelope
    envelope = butter_lowpass_filter(rectified, 10, fs)
    
    # Downsample by 10
    downsampled = envelope[::10]
    
    return downsampled

BoardShim.enable_dev_board_logger()
logging.basicConfig(level=logging.DEBUG)

params = MindRoveInputParams()
board_shim = BoardShim(BoardIds.MINDROVE_WIFI_BOARD, params)
board_shim.prepare_session()
board_shim.start_stream()

# Initialize PyQt application
app = QApplication(sys.argv)
win = pg.GraphicsLayoutWidget(show=True)
win.setWindowTitle('Real Time EMG Processing & Predictions')

# Create plots
emg_plot = win.addPlot(title='EMG Channels')
emg_plot.addLegend()

win.nextRow()
pred_plot = win.addPlot(title='Predictions')
pred_plot.addLegend()

# Configuration
sequence_length = 200  # Match your model's sequence length
max_buffer_size = sequence_length
window_size = 0.6
ms_spent = 50

# Load the trained model
model = torch.load('/home/mindrove-rpi/Downloads/real_time_model.pt')
model.eval()

# Initialize buffers for EMG and predictions
emg_buffers = {i: [] for i in range(8)}
prediction_buffers = {
    'angle': [],
    'mass': [],
    'torque': []
}

# Create curves for visualization
emg_curves = {}
pred_curves = {}

# EMG plot setup
emg_colors = ['b', 'g', 'r', 'c', 'm', 'y', 'w', 'k']
emg_names = [f'CH{i+1}' for i in range(8)]
for i in range(8):
    emg_curves[i] = emg_plot.plot(pen=pg.mkPen(color=emg_colors[i]), name=emg_names[i])

# Prediction plot setup
pred_colors = ['y', 'w', 'r']
pred_names = ['Angle', 'Mass', 'Torque']
for name, color in zip(pred_names, pred_colors):
    pred_curves[name] = pred_plot.plot(pen=pg.mkPen(color=color), name=name)

def update_plot():
    try:
        start_time = time.time()
        
        # Get and process EMG data
        data = board_shim.get_current_board_data(int(window_size * 500))
        processed_data = []
        
        # Process each EMG channel
        for i in range(8):
            channel_data = data[i]
            DataFilter.detrend(channel_data, DetrendOperations.CONSTANT.value)
            # DataFilter.perform_bandpass(channel_data, 500, 10.0, 450.0, 4,
            #                          FilterTypes.BUTTERWORTH.value, 0)
            processed = process_emg_channel(channel_data)
            processed_data.append(processed)
            
            # Update EMG buffers
            emg_buffers[i].extend(processed)
            if len(emg_buffers[i]) > max_buffer_size:
                emg_buffers[i] = emg_buffers[i][-max_buffer_size:]
        
        # Prepare model input
        processed_data = np.array(processed_data)  # Shape: [8, sequence_length]
        
        # Add time dimension
        time_row = np.linspace(0, 0.6, processed_data.shape[1])
        model_input = np.vstack((time_row, processed_data))  # Add time as first row
        model_input = torch.tensor(model_input).unsqueeze(0).to(torch.float32)
        
        # Get predictions
        with torch.no_grad():
            pred_angle, pred_mass = model(model_input)
            
            # Apply Gaussian filtering to angle predictions
            pred_angle = gaussian_filter(pred_angle.numpy(), sigma=10)
            pred_angle = torch.from_numpy(pred_angle)
            
            # Calculate torque using model's calc_torque method
            pred_torque = model.calc_torque(pred_angle, pred_mass, pred_mass)
        
        # Update prediction buffers
        for pred, buffer_name in zip([pred_angle, pred_mass, pred_torque], 
                                   ['angle', 'mass', 'torque']):
            prediction_buffers[buffer_name].extend(pred.numpy().flatten())
            if len(prediction_buffers[buffer_name]) > max_buffer_size:
                prediction_buffers[buffer_name] = prediction_buffers[buffer_name][-max_buffer_size:]
        
        # Update plots
        x = np.arange(max_buffer_size)
        
        # Update EMG plots with vertical offset for visibility
        for i in range(8):
            emg_curves[i].setData(x, np.array(emg_buffers[i]) - i * 100)
        
        # Update prediction plots
        for name in ['angle', 'mass', 'torque']:
            pred_curves[name].setData(x, np.array(prediction_buffers[name]))
        
        # Set plot ranges
        emg_plot.setXRange(x[0], x[-1])
        pred_plot.setXRange(x[0], x[-1])
        
        ms_spent = (time.time() - start_time) * 1000
        
    except Exception as e:
        logging.error(f'Exception in update_plot: {str(e)}', exc_info=True)

# Setup update timer
timer = QTimer()
timer.timeout.connect(update_plot)
timer.start(600 - ms_spent)

if __name__ == '__main__':
    sys.exit(app.exec_())